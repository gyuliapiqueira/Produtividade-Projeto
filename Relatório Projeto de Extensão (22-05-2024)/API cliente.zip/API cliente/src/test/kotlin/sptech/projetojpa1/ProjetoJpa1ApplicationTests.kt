package sptech.projetojpa1

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ProjetoJpa1ApplicationTests {

	@Test
	fun contextLoads() {
	}

}

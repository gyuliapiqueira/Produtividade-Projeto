package sptech.projetojpa1.dto

data class UsuarioFotoRequest (
    var foto: ByteArray
)
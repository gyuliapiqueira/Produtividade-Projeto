package sptech.projetojpa1.dto

data class StatusResponse(
    val id: Int?,
    val nome: String?,
    val cor: String?,
    val motivo: String?
)

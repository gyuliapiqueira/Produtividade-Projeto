package sptech.projetojpa1.dto

data class UsuarioLoginRequest(
    val email: String,
    val senha: String
)

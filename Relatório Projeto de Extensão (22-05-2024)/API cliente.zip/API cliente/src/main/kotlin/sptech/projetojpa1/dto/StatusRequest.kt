package sptech.projetojpa1.dto

data class StatusRequest(
    val nome: String,
    val cor: String?,
    val motivo: String?)
